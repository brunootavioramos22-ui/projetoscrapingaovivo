create table clientes(
	id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100),
    email VARCHAR(100)

);

create table pedidos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_cliente INT,
    data DATE,
    total DECIMAL(10,2),
    FOREIGN KEY (id_cliente) REFERENCES clientes(id)
);

select * from pedidos ;

insert into clientes (nome, email)
values
    ('Bruno', 'bruno@email.com'),
    ('Carlos', 'carlos@email.com'),
    ('Ana', 'ana@email.com');
    
insert into pedidos (id_cliente, data, total) 
values
	(1, '2025-01-10', 150.00),
	(1, '2025-01-15', 90.00),
	(2, '2025-01-12', 200.00),
	(3, '2025-01-20', 50.00);

SELECT DISTINCT c.id, c.nome, c.email
FROM clientes c
INNER JOIN pedidos p ON c.id = p.id_cliente
WHERE p.total > 100
ORDER BY c.nome ASC;

SELECT c.id, c.nome, COUNT(p.id) AS total_pedidos
FROM clientes c
LEFT JOIN pedidos p ON c.id = p.id_cliente
GROUP BY c.id, c.nome
ORDER BY c.nome ASC;
